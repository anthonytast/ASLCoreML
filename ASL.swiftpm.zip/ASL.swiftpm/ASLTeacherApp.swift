import SwiftUI

@main
struct ASLTeacherApp: App {
    @StateObject var appModel = AppModel()
    var body: some Scene {
        WindowGroup {
            NavigationSideBarView()
                .environmentObject(appModel)
                .task {
                    await appModel.useLastTrainedModel()
                }
        }
    }
}
