import SwiftUI

struct SignCView: View {
    
    var body: some View {
        HStack{
            VStack{
                Spacer()
                Image("CSign")
                    .resizable()
                    .frame(width: 350, height: 350)
                Spacer()
                Text("This is the sign for the letter C. Hold your hand in a curve shape to look like the letter C. Be sure that the C can be read in the right direction to whomever is in front of you; do not have the C face you.")
                    .font(.title3)
                    .padding()
                Text("Try it yourself in the ML Camera View and continue to the concluding view when you are ready.")
                    .font(.title3)
                    .padding()
                Spacer()
            }
            .navigationTitle("Sign C")
            MLCameraView()
        }
    }
}

struct SignCView_Previews: PreviewProvider {
    static var previews: some View {
        SignCView()
    }
}
