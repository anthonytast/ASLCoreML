import SwiftUI

struct WelcomeView: View {
    
    @State var isPresented = true
    
    var body: some View {
        VStack{
            Spacer()
            
            Text("Welcome")
                .font(.title)
                .font(.system(size: 50))
                .bold()
                .foregroundColor(Color(.label))
            
            HStack{
                VStack{
                    Image("ASign")
                        .resizable()
                        .frame(width: 350, height: 350)
                    Text("A")
                        .font(.title)
                        .bold()
                }
                VStack{
                    Image("BSign")
                        .resizable()
                        .frame(width: 350, height: 350)
                    Text("B")
                        .font(.title)
                        .bold()
                }
                VStack{
                    Image("CSign")
                        .resizable()
                        .frame(width: 350, height: 350)
                    Text("C")
                        .font(.title)
                        .bold()
                }
            }
            Spacer()
            Text("This app is called ASL Teacher. It is a basic introduction to ASL (American Sign Language). You will be reviewing basic alphabet signs while Core ML detects which of the three signs you are trying to do. The letter sign being detected will show in the bottom righthand corner of the Camera View. We will be reviewing the signs for the letters A, B, and C. Start by going to Sign A.")
                .font(.title3)
                .padding()
            
            Spacer()
        }
        .navigationTitle("Introduction")
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
