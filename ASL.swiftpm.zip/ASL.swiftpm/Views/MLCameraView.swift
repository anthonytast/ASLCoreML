//
//  ContentView.swift
//  ASL Teacher (Swift Student)
//
//  Created by Anthony Tast on 4/17/23.
//

import SwiftUI

struct MLCameraView: View {
    
    @EnvironmentObject var appModel: AppModel
    @StateObject var gameModel = GameModel()
    @State private var predictedMove: String = GameMove.unknown.name
    @State private var gameResultText: String = ""
    
    
    var body: some View {
        camera()
    }
    
    private func camera() -> some View {
        CameraView()
            .environmentObject(appModel)
            .onChange(of: gameModel.currentState) { _ in
                updateCameraAppearance(currentState: gameModel.currentState)
            }
            .onChange(of: appModel.predictionLabel) { _ in
                guard gameModel.currentState != .finished else { return }
                updateYourMove(with: appModel.predictionLabel)
                
            }
            .overlay(alignment: .bottom) {
                VStack {
                    PredictionLabelOverlay(label: appModel.predictionLabel)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    //                  playButton()
                    //                      .background(Color.translucentBlack)
                }
            }
    }
    
    private func updateYourMove(with predicationLabel: String) {
        guard !predicationLabel.isEmpty else {
            gameModel.yourMoveName = GameMove.unknown.name
            return
        }
        predictedMove = predicationLabel
        gameModel.yourMoveName = predictedMove
    }
    
    private func updateCameraAppearance(currentState: GameState) {
        switch currentState {
        case .playing:
            appModel.shouldPauseCamera = true
        case .finished:
            appModel.isGatheringObservations = false
            Task {
                await Task.sleep(seconds: 1.5)
        //        gameResultText = ""
                appModel.shouldPauseCamera = false
      //          gameModel.currentState = .notPlaying
            }
        case .notPlaying:
            appModel.shouldPauseCamera = false
        }
    }
}




struct MLCameraView_Previews: PreviewProvider {
    static var previews: some View {
        MLCameraView()
    }
}
