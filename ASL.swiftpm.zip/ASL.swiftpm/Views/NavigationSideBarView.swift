import SwiftUI

struct NavigationSideBarView: View {
    
    @State var isPresented = true
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        NavigationView{
            List{
                NavigationLink(destination: WelcomeView()) {
                    Text("Welcome")
                }
                NavigationLink(destination: SignAView()) {
                    Text("Sign A")
                }
                NavigationLink(destination: SignBView()) {
                    Text("Sign B")
                }
                NavigationLink(destination: SignCView()) {
                    Text("Sign C")
                }
                NavigationLink(destination: ConclusionView()) {
                    Text("Conclusion")
                }
                
            }
            .navigationTitle("ASL Teacher")
        }
    }
}

struct NavigationSideBarView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationSideBarView()
    }
}
