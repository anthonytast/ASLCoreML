import SwiftUI

struct SignBView: View {
    
    var body: some View {
        HStack{
            VStack{
                Spacer()
                Image("BSign")
                    .resizable()
                    .frame(width: 350, height: 350)
                Spacer()
                Text("This is the sign for the letter B. Hold your hand flat and straight up. Then, hold your thumb nearly horizontal across the front of your hand.")
                    .font(.title3)
                    .padding()
                Text("Try it yourself in the ML Camera View and continue to Sign C once you are ready.")
                    .font(.title3)
                    .padding()
                Spacer()
            }
            .navigationTitle("Sign B")
            MLCameraView()
        }
    }
}

struct SignBView_Previews: PreviewProvider {
    static var previews: some View {
        SignBView()
    }
}
