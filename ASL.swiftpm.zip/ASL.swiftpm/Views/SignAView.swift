import SwiftUI

struct SignAView: View {
    
    var body: some View {
        HStack{
            VStack{
                Spacer()
                Image("ASign")
                    .resizable()
                    .frame(width: 350, height: 350)
                Spacer()
                Text("This is the hand signal (or sign) for the letter A. Hold your hand as a fist with your fingers going straight down. Also, be sure to hold your thumb straight up.")
                    .font(.title3)
                    .padding()
                Text("Try it yourself in the ML Camera View and continue to Sign B once you are ready.")
                    .font(.title3)
                    .padding()
                Spacer()
            }
            .navigationTitle("Sign A")
            MLCameraView()
        }
    }
}

struct SignAView_Previews: PreviewProvider {
    static var previews: some View {
        SignAView()
    }
}
