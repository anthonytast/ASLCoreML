import SwiftUI

struct ConclusionView: View {
    
    @State var isPresented = true
    
    var body: some View {
            VStack{
                Spacer()
                Text("Conclusion")
                    .font(.title)
                    .bold()
                    .foregroundColor(Color(.label))
                    .padding()
                HStack{
                    VStack{
                        Image("ASign")
                            .resizable()
                            .frame(width: 350, height: 350)
                        Text("A")
                            .font(.title)
                            .bold()
                    }
                    VStack{
                        Image("BSign")
                            .resizable()
                            .frame(width: 350, height: 350)
                        Text("B")
                            .font(.title)
                            .bold()
                    }
                    VStack{
                        Image("CSign")
                            .resizable()
                            .frame(width: 350, height: 350)
                        Text("C")
                            .font(.title)
                            .bold()
                    }
                }
                Spacer()
                Text("I hope you enjoyed learning some basic sign language! I highly encourage you to research learning more of the ASL alphabet and other signs as well. Thank you for time.")
                    .font(.title3)
                    .padding()
                Spacer()
            }
            .navigationTitle("Ending")
    }
}

struct ConclusionView_Previews: PreviewProvider {
    static var previews: some View {
        ConclusionView()
    }
}
